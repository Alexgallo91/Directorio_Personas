<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Correo extends Model
{
    protected $table = 'correos';
    protected $primaryKey = 'id_pk_correo';
    public $timestamps = false;
}
