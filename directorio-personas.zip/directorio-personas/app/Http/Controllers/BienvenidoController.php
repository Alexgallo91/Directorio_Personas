<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class BienvenidoController extends Controller
{
    public function bienvenido(){
        $title = 'Bienvenido';
        return view('bienvenido', compact('title'));
    }
}
