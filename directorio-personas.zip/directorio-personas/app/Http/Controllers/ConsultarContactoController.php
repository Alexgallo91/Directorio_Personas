<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Persona;
use App\Telefono;
use App\Direccion;
use App\Correo;
use Illuminate\Support\Facades\DB;

class ConsultarContactoController extends Controller
{
    public function paginaInicioConsulta()
    {
        $title = 'Consultar Contacto';
        return view('libretaContactos\buscarContacto', compact('title'));
    }

    public function consultarPersona(Request $request)
    {
        $parametroLike = '%' . $request->nombre . '%';
        $personas = Persona::where('nombre', 'LIKE', $parametroLike)
            ->orwhere('apellido_paterno', 'LIKE', '%' . $parametroLike)
            ->orwhere('apellido_materno', 'LIKE', '%' . $parametroLike)->get();

        return $personas;
    }

    public function consultarContactoConId($id)
    {
        $title = 'Consultar Contacto';

        $persona = Persona::where('id_pk_persona', $id)->first();
        $telefonos = Telefono::where('id_fk_persona', '=', $id)->get();
        $correos = Correo::where('id_fk_persona', '=', $id)->get();
        $direcciones = Direccion::where('id_fk_persona', '=', $id)->get();

        return view('libretaContactos\consultarContacto',
            compact('title', 'id', 'persona',
                'telefonos', 'correos', 'direcciones'));
    }

    public function eliminarContacto(Request $request)
    {
        $idPersonaPorEliminar = $request->idPersonaPorEliminar;
        /*        $personaObtenida = Persona::find($idPersonaPorEliminar);
                $personaObtenida->delete();*/

        DB::delete('delete from libreta_contactos.personas where id_pk_persona = ?', [$idPersonaPorEliminar]);

        return response()->json(['numeroUsuario' => $request->idPersonaPorEliminar]);
    }

    public function crearContacto(Request $request)
    {
        $nombre = $request->nombre;
        $apellidoPaterno = $request->apellidoPaterno;
        $apellidoMaterno = $request->apellidoMaterno;
        $fechaNacimiento = $request->fechaNacimiento;
        $alias = $request->alias;

        DB::insert('insert into libreta_contactos.personas (nombre, apellido_paterno, apellido_materno, alias, fecha_nacimiento
        ) values (?, ?, ?, ?, ?)', [$nombre, $apellidoPaterno, $apellidoMaterno, $alias, $fechaNacimiento]);

        //se obtiene el max del id_pk que se genero en la insercion
        $max_id_pk = DB::table('personas')->max('id_pk_persona');

        //se insertan direcciones
        if (count($request->direcciones) > 0) {
            foreach ($request->direcciones as $direccion) {
                $dir = $direccion['direccion'];

                DB::table('direcciones')->insert(
                    ['direccion' => $dir, 'id_fk_persona' => $max_id_pk]
                );
            }
        }
        //se insertan telefonos
        if (count($request->telefonos) > 0) {
            foreach ($request->telefonos as $telefono) {
                $phone = $telefono['telefono'];
                $etiqueta = $telefono['etiqueta'];

                DB::table('telefonos')->insert(
                    ['telefono' => $phone, 'etiqueta' => $etiqueta, 'id_fk_persona' => $max_id_pk]
                );
            }
        }

        //se insertan correos
        if (count($request->correos) > 0) {
            foreach ($request->correos as $correo) {
                $email = $correo['correo'];

                DB::table('correos')->insert(
                    ['correo' => $email, 'id_fk_persona' => $max_id_pk]
                );
            }
        }

        return response()->json(['code' => 'success']);
    }

    public function actualizarPersona(Request $request)
    {
        $idPk = $request->idPk;
        $nombre = $request->nombre;
        $apellidoPaterno = $request->apellidoPaterno;
        $apellidoMaterno = $request->apellidoMaterno;
        $fechaNacimiento = $request->fechaNacimiento;
        $alias = $request->alias;
        $result = true;

        try {
            DB::beginTransaction();

            //se hace update de la informacion del usuario
            $persona = Persona::where('id_pk_persona', $idPk)->first();
            $persona->nombre = $nombre;
            $persona->apellido_paterno = $apellidoPaterno;
            $persona->apellido_materno = $apellidoMaterno;
            $persona->alias = $alias;
            $persona->fecha_nacimiento = $fechaNacimiento;
            $persona->save();

            //se eliminan correos, direcciones y telefonos relacionados al contacto
            Direccion::where('id_fk_persona', $idPk)->delete();
            Correo::where('id_fk_persona', $idPk)->delete();
            Telefono::where('id_fk_persona', $idPk)->delete();

            //se insertan direcciones, telefonos y correos
            foreach ($request->direcciones as $direccion) {
                $insertDireccion = new Direccion;
                $insertDireccion->direccion = $direccion['direccion'];
                $insertDireccion->id_fk_persona = $idPk;
                $insertDireccion->save();
            }

            foreach ($request->correos as $correo) {
                $insertCorreo = new Correo;
                $insertCorreo->correo = $correo['correo'];
                $insertCorreo->id_fk_persona = $idPk;
                $insertCorreo->save();
            }

            foreach ($request->telefonos as $telefono) {
                $insertTelefono = new Telefono;
                $insertTelefono->telefono = $telefono['telefono'];
                $insertTelefono->etiqueta= $telefono['etiqueta'];
                $insertTelefono->id_fk_persona = $idPk;
                $insertTelefono->save();
            }

            DB::commit();
        } catch (\Exception $e) {
            $result = $e;
            DB::rollback();
        }

        return response()->json(['code' => $result, 'id' => $idPk, 'persona' => $persona]);
    }

    public function consultarVistaCrearContacto(Request $request)
    {
        $title = 'Crear contacto';
        return view('libretaContactos\crearContacto', compact('title'));
    }
}
