<?php

/*------------ROUTES APLICATIVO LIBRETA DE CONTACTOS-------------*/

Route::get('/', 'BienvenidoController@bienvenido');

Route::get('/consultarContacto', 'ConsultarContactoController@paginaInicioConsulta');

Route::get('/consultarContacto/{id}', 'ConsultarContactoController@consultarContactoConId');

Route::get('/paginaCrearContacto', 'ConsultarContactoController@consultarVistaCrearContacto');

//AJAX
Route::post('/crearContacto', 'ConsultarContactoController@crearContacto');

Route::post('/consultarContactoPorNombre', 'ConsultarContactoController@consultarPersona');

Route::post('/eliminarPersona', 'ConsultarContactoController@eliminarContacto');

Route::post('/actualizarPersona','ConsultarContactoController@actualizarPersona');



