<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePersonasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('personas', function (Blueprint $table) {
            $table->increments('id_pk_persona');
            $table->string('nombre', 40)->nullable($value = false);
            $table->string('apellido_paterno', 30)->nullable($value = false);
            $table->string('apellido_materno', 30)->nullable($value = false);
            $table->string('alias', 30);
            $table->string('imagen_perfil', 30);
            $table->date('fecha_nacimiento')->nullable($value = false);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('personas');
    }
}
