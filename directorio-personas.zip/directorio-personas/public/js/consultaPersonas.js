$(document).ready(function () {

    //actualizacion de contacto
    $('#botonModificarContacto').click(function () {

        var jsonObjectEnvio = {};
        var idPk = $('#idPk').val();
        var nombre = $('#nombre').val();
        var apellidoPaterno = $('#apellidoPaterno').val();
        var apellidoMaterno = $('#apellidoMaterno').val();
        var fechaNacimiento = $('#fechaNacimiento').val();
        var alias = $('#alias').val();
        var telefonos = [];
        var correos = [];
        var direcciones = [];

        //se obtienen los telefonos
        $('#tablaNumeroTelefono > tbody  > tr').each(function () {
            var etiqueta = this.cells[0].textContent;
            var telefono = this.cells[1].textContent;

            var telObj = {'etiqueta': etiqueta, 'telefono': telefono};
            telefonos.push(telObj);
        });

        //se obtienen los correos
        $('#tablaCorreos > tbody  > tr').each(function () {
            var correo = this.cells[0].textContent;

            var corrObj = {'correo': correo};
            correos.push(corrObj);
        });

        //se obtienen las direcciones
        $('#tablaDireccion > tbody  > tr').each(function () {
            var direccion = this.cells[0].textContent;

            var dirObj = {'direccion': direccion};
            direcciones.push(dirObj);
        });

        //verifica que al menos haya corre, direccion y telefono
        if (jQuery.isEmptyObject(telefonos)) {
            $.sweetModal({
                content: 'Favor de establecer al menos un telefono',
                icon: $.sweetModal.ICON_WARNING
            });
            return;
        }

        if (jQuery.isEmptyObject(correos)) {
            $.sweetModal({
                content: 'Favor de establecer al menos un correo',
                icon: $.sweetModal.ICON_WARNING
            });
            return;
        }

        if (jQuery.isEmptyObject(direcciones)) {
            $.sweetModal({
                content: 'Favor de establecer al menos una direccion',
                icon: $.sweetModal.ICON_WARNING
            });
            return;
        }

        jsonObjectEnvio.idPk = idPk;
        jsonObjectEnvio.nombre = nombre;
        jsonObjectEnvio.apellidoPaterno = apellidoPaterno
        jsonObjectEnvio.apellidoMaterno = apellidoMaterno
        jsonObjectEnvio.fechaNacimiento = fechaNacimiento
        jsonObjectEnvio.alias = alias;
        jsonObjectEnvio.telefonos = telefonos;
        jsonObjectEnvio.correos = correos;
        jsonObjectEnvio.direcciones = direcciones;

        $.ajax({
            data: jsonObjectEnvio,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            },
            async: false,
            type: 'POST',
            dataType: 'JSON',
            url: '/actualizarPersona',
        })
            .done(function (data, textStatus, jqXHR) {
                console.log(data + ' ' + textStatus + ' ' + jqXHR);
                $.sweetModal({
                    content: 'Se ha actualizado el contacto de manera exitosa',
                    icon: $.sweetModal.ICON_SUCCESS,
                    onClose: function(){window.location.href = "/consultarContacto";},
                });
            })
            .fail(function (jqXHR, textStatus, errorThrown) {
                console.log('Llamada ajax fallida: ' + textStatus + jqXHR.responseText + errorThrown);
            });
    });

    $('#botonCrearContacto').click(function () {

        var jsonObjectEnvio = {};
        var nombre = $('#nombre').val();
        var apellidoPaterno = $('#apellidoPaterno').val();
        var apellidoMaterno = $('#apellidoMaterno').val();
        var fechaNacimiento = $('#fechaNacimiento').val();
        var alias = $('#alias').val();
        var telefonos = [];
        var correos = [];
        var direcciones = [];

        //se obtienen los telefonos
        $('#tablaNumeroTelefono > tbody  > tr').each(function () {
            var etiqueta = this.childNodes[0].textContent;
            var telefono = this.childNodes[1].textContent;

            var telObj = {'etiqueta': etiqueta, 'telefono': telefono};
            telefonos.push(telObj);
        });

        //se obtienen los correos
        $('#tablaCorreos > tbody  > tr').each(function () {
            var correo = this.childNodes[0].textContent;

            var corrObj = {'correo': correo};
            correos.push(corrObj);
        });

        //se obtienen las direcciones
        $('#tablaDireccion > tbody  > tr').each(function () {
            var direccion = this.childNodes[0].textContent;

            var dirObj = {'direccion': direccion};
            direcciones.push(dirObj);
        });

        //verifica que al menos haya corre, direccion y telefono
        if (jQuery.isEmptyObject(telefonos)) {
            $.sweetModal({
                content: 'Favor de establecer al menos un telefono',
                icon: $.sweetModal.ICON_WARNING
            });
            return;
        }

        if (jQuery.isEmptyObject(correos)) {
            $.sweetModal({
                content: 'Favor de establecer al menos un correo',
                icon: $.sweetModal.ICON_WARNING
            });
            return;
        }

        if (jQuery.isEmptyObject(direcciones)) {
            $.sweetModal({
                content: 'Favor de establecer al menos una direccion',
                icon: $.sweetModal.ICON_WARNING
            });
            return;
        }

        jsonObjectEnvio.nombre = nombre;
        jsonObjectEnvio.apellidoPaterno = apellidoPaterno
        jsonObjectEnvio.apellidoMaterno = apellidoMaterno
        jsonObjectEnvio.fechaNacimiento = fechaNacimiento
        jsonObjectEnvio.alias = alias;
        jsonObjectEnvio.telefonos = telefonos;
        jsonObjectEnvio.correos = correos;
        jsonObjectEnvio.direcciones = direcciones;

        $.ajax({
            data: jsonObjectEnvio,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            },
            async: false,
            type: 'POST',
            dataType: 'JSON',
            url: '/crearContacto',
        })
            .done(function (data, textStatus, jqXHR) {
                console.log(data + ' ' + textStatus + ' ' + jqXHR);
                $.sweetModal({
                    content: 'Contacto guadado exitosamente',
                    icon: $.sweetModal.ICON_SUCCESS,
                    onClose: function(){window.location.href = "/consultarContacto";},
                });
            })
            .fail(function (jqXHR, textStatus, errorThrown) {
                console.log('Llamada ajax fallida: ' + textStatus + jqXHR + errorThrown);
            });
    });


    $("#tablaNumeroTelefono").on("click", ".btnRowEliminar", function (e) {
        e.preventDefault();
        $(this).parents("tr").remove();
    });

    $("#tablaDireccion").on("click", ".btnRowEliminar", function (e) {
        e.preventDefault();
        $(this).parents("tr").remove();
    });

    $("#tablaCorreos").on("click", ".btnRowEliminar", function (e) {
        e.preventDefault();
        $(this).parents("tr").remove();
    });


    $('#botonConsultar').click(function () {

        var inputConsulta = $('#inputConsulta').val();

        if (!notNullAndEmptyField(inputConsulta)) {
            inputConsulta = inputConsulta.trim();
            var dataPorEnviar = {};
            dataPorEnviar.nombre = inputConsulta;

            $.ajax({
                data: dataPorEnviar,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                },
                async: false,
                type: 'POST',
                dataType: 'JSON',
                url: '/consultarContactoPorNombre',
            })
                .done(function (data, textStatus, jqXHR) {
                    console.log('Llamada ajax con exito: ' + textStatus);
                    //limpia la tabla
                    /*$('#tablaResultContactos > tr > td').remove();*/
                    $("#tablaResultContactos tbody").empty();
                    //pobla la tabla
                    $.each(data, function (i, item) {
                        var $tr = $('<tr>').append(
                            $('<td>').text(item.nombre + ' ' + item.apellido_paterno + ' ' + item.apellido_materno),
                            $('<td>').append('<button type="button" onclick="eliminarContacto(' + item.id_pk_persona
                                + ')" class="btn btn-danger btn-space">Eliminar</button>' +
                                '<button type="button"  onclick="location.href=' + '\'consultarContacto/'
                                + item.id_pk_persona + '\'" class="btn btn-success">Consultar</button>')
                        );
                        $('#tablaResultContactos > tbody:last-child').append($tr);
                    });

                    $('#tablaResultContactos').show();
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    console.log('Llamada ajax fallida: ' + textStatus + jqXHR + errorThrown);
                });
        } else {
            $.sweetModal({
                content: 'Favor de ingresar el nombre de la persona que desea consultar',
                icon: $.sweetModal.ICON_WARNING
            });
        }
    });
});

function eliminarContacto(idPkPersona) {
    $.sweetModal.confirm('Eliminar Contacto', 'Desea eliminar el contacto seleccionado?', function () {
        $.ajax({
            data: {'idPersonaPorEliminar': idPkPersona},
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            },
            async: false,
            type: 'POST',
            dataType: 'JSON',
            url: '/eliminarPersona',
        })
            .done(function (data, textStatus, jqXHR) {
                console.log(data + ' ' + textStatus + ' ' + jqXHR);
                $('#tablaResultContactos').hide();
                $.sweetModal({
                    content: 'Contacto eliminado con exito',
                    icon: $.sweetModal.ICON_SUCCESS
                });
            })
            .fail(function (jqXHR, textStatus, errorThrown) {
                console.log('Llamada ajax fallida: ' + textStatus + jqXHR.responseText + errorThrown);
            });
    });
}

function agregarNuevoTelefono() {
    if (!notNullAndEmptyField($('#nuevaEtiqueta').val()) && !notNullAndEmptyField($('#nuevoTelefono').val())) {

        var btnEliminar = '<button type="button" class="btnRowEliminar btn btn-danger text-light">Eliminar</button>';

        $('#tablaNumeroTelefono').append('<tr><td class="etiqueta">' + $('#nuevaEtiqueta').val() +
            '</td><td class="telefono">' + $('#nuevoTelefono').val() + '</td><td>' + btnEliminar + '</td></tr>');
        $('#modalTelefono').modal('hide');
    }
}


function agregarNuevoDireccion() {
    if (!notNullAndEmptyField($('#nuevaDireccion').val())) {

        var btnEliminar = '<button type="button" class="btnRowEliminar btn btn-danger text-light">Eliminar</button>';

        $('#tablaDireccion').append('<tr><td>' + $('#nuevaDireccion').val() + '</td><td>' + btnEliminar + '</td></tr>');
        $('#modalDireccion').modal('hide');
    }
}


function agregarNuevoCorreo() {
    if (!notNullAndEmptyField($('#nuevoCorreo').val()) && validarEmail($('#nuevoCorreo').val())) {

        var btnEliminar = '<button type="button" class="btnRowEliminar btn btn-danger text-light">Eliminar</button>';

        $('#tablaCorreos').append('<tr><td>' + $('#nuevoCorreo').val() + '</td><td>' + btnEliminar + '</td></tr>');
        $('#modalCorreo').modal('hide');
    }
}

