@extends('layouts.app', ['title' => $title])

@section('content')

    <section class="jumbotron text-center jumbo-principal">

        <div class="container">
            <h1 class="jumbotron-heading">Guarda tus contactos</h1>
            <p class="lead text-muted">Bienvenido al aplicativo 'Libreta de Contactos'. No esperes y guarda tus contactos.</p>
            <p>
                <a href="{{url('/consultarContacto')}} " class="btn btn-primary my-2 bg-success">Ingresar</a>
            </p>
        </div>
    </section>
@stop

@section('footer')

@stop