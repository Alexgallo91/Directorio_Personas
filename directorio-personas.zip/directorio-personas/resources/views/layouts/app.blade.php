<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="_token" content="{{ csrf_token() }}"/>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{ asset('css/jquery.sweet-modal.min.css')}}">
    <link rel="stylesheet" href="{{ asset('css/estilos.css')}}">

    {{--js--}}
    <script src="{{asset('js/jquery.min.js')}}"></script>
    <script src="{{asset('js/popper.min.js')}}"></script>
    <script src="{{asset('js/bootstrap.min.js')}}"></script>
    <script src="{{asset('js/jquery.sweet-modal.min.js')}}"></script>
    <script src="{{asset('js/global.js')}}"></script>

    <title>{{$title}}</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">

    <a class="navbar-brand" href="#">
            <span><img src="{{ asset('img/logo.png')}}" alt="" height="40" width="40">
            Libreta de Contactos</span>

    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
            aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="{{url('/')}}">Inicio
                    <span class="sr-only">(current)</span>
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">

    @yield('content')
</div>

@yield('footer')
</body>
</html>