@extends('layouts.app', ['title' => $title])

@section('content')
    <script src="{{asset('js/consultaPersonas.js')}}"></script>

    <section class="jumbotron text-center jumbo-principal">

        <div class="container">
            <h1 class="jumbotron-heading jumbo">Buscar Contacto</h1>
            <p class="lead text-muted">Favor de consultar al contacto</p>
            <div class="input-group">
                <input type="text" id="inputConsulta" class="form-control" placeholder="Favor de ingresar el nombre de la persona que desea consultar..." name="buscar">
                <div class="input-group-btn">
                    <button type="button" id="botonConsultar" class="btn btn-primary">Consultar</button>
                </div>
            </div>

            {{--tabla donde se mostraran los contactos encontrados--}}
            <table class="table table-striped" id="tablaResultContactos">
                <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <br>
            <a class="btn btn-success" href="paginaCrearContacto" role="button">Crear Contacto</a>
        </div>
    </section>
@stop

@section('footer')


@stop