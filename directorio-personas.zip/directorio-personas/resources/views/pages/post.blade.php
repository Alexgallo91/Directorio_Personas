@extends('layouts.app')

@section('content')
    <h1>Post Page</h1>
    <h2>Tus variables son {{$id}} {{$name}} {{$pass}}</h2>

@stop