<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(asset('js/consultaPersonas.js')); ?>"></script>

    <section class="jumbotron text-center jumbo-principal">

        <div class="container">
            <h1 class="jumbotron-heading jumbo">Consulta Contacto</h1>
            <br>
            <form method="POST" id="formContacto">
                <div class="form-group row">
                    <label for="nombre" class="col-sm-3 col-form-label bg-success text-light">Nombre</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control-plaintext bg-light" id="nombre"
                               value="">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="apellidoPaterno" class="col-sm-3 col-form-label bg-success text-light">Apellido
                        Paterno</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control-plaintext bg-light" id="apellidoPaterno"
                               value="">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="apellidoMaterno" class="col-sm-3 col-form-label bg-success text-light">Apellido
                        Materno</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control-plaintext bg-light" id="apellidoMaterno"
                               value="">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="fechaNacimiento" class="col-sm-3 col-form-label bg-success text-light">Fecha
                        Nacimiento</label>
                    <div class="col-sm-9">
                        <input type="date" class="form-control-plaintext bg-light" id="fechaNacimiento"
                               value="">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="alias" class="col-sm-3 col-form-label bg-success text-light">Alias</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control-plaintext bg-light" id="alias"
                               value="">
                    </div>
                </div>

                <?php /*Acordion direcciones, correos y telefonos*/ ?>
                <div class="panel-group" id="acordionContacto">

                    <div class="panel-group" id="accordion">
                        <div class="panel panel-default">
                            <div class="panel-heading bg-info">
                                <h4 class="panel-title text-light">
                                    <a class="text-light text-decoration: none !important" data-toggle="collapse"
                                       data-parent="#accordion" href="#collapse1">
                                        Telefonos</a>
                                </h4>
                            </div>
                            <div id="collapse1" class="panel-collapse collapse in bg-light">
                                <div class="panel-body">
                                    <?php /*tabla donde se mostraran los contactos encontrados*/ ?>
                                    <table class="table table-striped" id="tablaNumeroTelefono">
                                        <thead>
                                        <tr>
                                            <th>Etiqueta</th>
                                            <th>Numero Telefono</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                    <button type="button" id="botonAgregarTelefono" class="btn btn-primary"
                                            data-toggle="modal" data-target="#modalTelefono">Agregar Telefono
                                    </button>
                                    </br></br>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading bg-info">
                                <h4 class="panel-title">
                                    <a class="text-light text-decoration: none !important" data-toggle="collapse"
                                       data-parent="#accordion" href="#collapse2">
                                        Direcciones</a>
                                </h4>
                            </div>
                            <div id="collapse2" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <?php /*tabla donde se mostraran los contactos encontrados*/ ?>
                                    <table class="table table-striped" id="tablaDireccion">
                                        <thead>
                                        <tr>
                                            <th>Dirección</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                    <button type="button" id="botonAgregarDireccion" data-toggle="modal"
                                            data-target="#modalDireccion" class="btn btn-primary">Agregar
                                        Dirección
                                    </button>
                                    </br></br>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading bg-info">
                                <h4 class="panel-title">
                                    <a class="text-light text-decoration: none !important" data-toggle="collapse"
                                       data-parent="#accordion" href="#collapse3">
                                        Correos Electronicos</a>
                                </h4>
                            </div>
                            <div id="collapse3" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <?php /*tabla donde se mostraran los contactos encontrados*/ ?>
                                    <table class="table table-striped" id="tablaCorreos">
                                        <thead>
                                        <tr>
                                            <th>Correo Electronico</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                    <button type="button" data-toggle="modal" data-target="#modalCorreo"
                                            id="botonAgregarCorreo" class="btn btn-primary">Agregar
                                        Correo
                                    </button>
                                    </br></br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <br>
                <button type="button" id="botonCrearContacto" class="btn btn-info text-light">Crear nuevo contacto
                </button>

                <?php /*modals*/ ?>
                <?php /*modal telefono*/ ?>
                <div class="modal fade" id="modalTelefono" tabindex="-1" role="dialog"
                     aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Agregar Telefono</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="nuevaEtiqueta">Etiqueta</label>
                                    <input type="text" class="form-control" id="nuevaEtiqueta"
                                           placeholder="Ingresa la etiqueta del telefono">
                                </div>
                                <div class="form-group">
                                    <label for="nuevoTelefono">Telefono</label>
                                    <input type="text" class="form-control" id="nuevoTelefono"
                                           placeholder="Ingresa el numero de telefono">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                <button type="button" class="btn btn-primary" onclick="agregarNuevoTelefono()" id="verificarTelefono">Agregar Telefono
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <?php /*modal Direccion*/ ?>
                <div class="modal fade" id="modalDireccion" tabindex="-1" role="dialog"
                     aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Agregar Direccion</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="nuevaDireccion">Direccion</label>
                                    <input type="text" class="form-control" id="nuevaDireccion"
                                           placeholder="Ingresa la nueva dirección">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                <button type="button" class="btn btn-primary" onclick="agregarNuevoDireccion()" id="verificarDireccion">Agregar
                                    Dirección
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <?php /*modal Direccion*/ ?>
                <div class="modal fade" id="modalCorreo" tabindex="-1" role="dialog"
                     aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Agregar Correo</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="nuevoCorreo">Correo</label>
                                    <input type="email" class="form-control" id="nuevoCorreo"
                                           placeholder="Ingresa el nuevo correo electronico">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                <button type="button" class="btn btn-primary" onclick="agregarNuevoCorreo()" id="verificarCorreo">Agregar Correo
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </form>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $title], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>