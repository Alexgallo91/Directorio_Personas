<?php $__env->startSection('content'); ?>

    <section class="jumbotron text-center jumbo-principal">

        <div class="container">
            <h1 class="jumbotron-heading">Guarda tus contactos</h1>
            <p class="lead text-muted">Bienvenido al aplicativo 'Libreta de Contactos'. No esperes y guarda tus contactos.</p>
            <p>
                <a href="<?php echo e(url('/consultarContacto')); ?> " class="btn btn-primary my-2 bg-success">Ingresar</a>
            </p>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $title], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>