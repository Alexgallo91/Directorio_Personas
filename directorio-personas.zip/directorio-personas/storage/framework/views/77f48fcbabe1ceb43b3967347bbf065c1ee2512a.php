<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(asset('js/consultaPersonas.js')); ?>"></script>

    <section class="jumbotron text-center jumbo-principal">

        <div class="container">
            <h1 class="jumbotron-heading jumbo">Buscar Contacto</h1>
            <p class="lead text-muted">Favor de consultar al contacto</p>
            <div class="input-group">
                <input type="text" id="inputConsulta" class="form-control" placeholder="Favor de ingresar el nombre de la persona que desea consultar..." name="buscar">
                <div class="input-group-btn">
                    <button type="button" id="botonConsultar" class="btn btn-primary">Consultar</button>
                </div>
            </div>

            <?php /*tabla donde se mostraran los contactos encontrados*/ ?>
            <table class="table table-striped" id="tablaResultContactos">
                <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $title], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>