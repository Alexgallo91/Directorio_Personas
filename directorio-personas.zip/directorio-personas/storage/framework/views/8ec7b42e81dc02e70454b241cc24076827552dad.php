<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>"/>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.sweet-modal.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">

    <?php /*js*/ ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.sweet-modal.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/global.js')); ?>"></script>

    <title><?php echo e($title); ?></title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">

    <a class="navbar-brand" href="#">
            <span><img src="<?php echo e(asset('img/logo.png')); ?>" alt="" height="40" width="40">
            Libreta de Contactos</span>

    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
            aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(url('/')); ?>">Inicio
                    <span class="sr-only">(current)</span>
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">

    <?php echo $__env->yieldContent('content'); ?>
</div>

<?php echo $__env->yieldContent('footer'); ?>
</body>
</html>