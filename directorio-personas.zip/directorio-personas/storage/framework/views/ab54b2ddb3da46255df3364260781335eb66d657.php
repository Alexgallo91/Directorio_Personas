<?php $__env->startSection('content'); ?>
    <h1>Contact Page</h1>

    <ul>

        <?php if(count($people)): ?>
            <?php foreach($people as $person): ?>
                <li><?php echo e($person); ?></li>
            <?php endforeach; ?>
        <?php endif; ?>

    </ul>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php /*<script>*/ ?>
        <?php /*alert('a la verga');*/ ?>
    <?php /*</script>*/ ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>